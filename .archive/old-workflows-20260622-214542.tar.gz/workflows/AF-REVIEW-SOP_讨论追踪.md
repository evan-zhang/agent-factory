# AF-REVIEW-SOP 讨论追踪

> 用途：记录评审 SOP 落地过程中需 Evan 拍板的问题、已定决策、待核实事项。
> 防止长会话过程中遗忘。每次有进展就更新。

- 关联文档：AF-REVIEW-SOP_独立评审标准流程.md（v1.0 DRAFT）
- 创建日期：2026-06-13

---

## 待讨论问题清单（逐个讨论，不跳过）

| 编号 | 问题 | 状态 |
|---|---|---|
| Q1 | Reviewer 用独立 agent id（factory-reviewer），还是复用 orchestrator 身份 spawn？ | ✅ 已定方向：方案 A（独立 agent），落地前需核实机制 |
| Q2 | 固定评审模型选哪个（claude-opus-4-8 / 其他）？ | ✅ 已定 |
| Q3 | C 类代码评审是否引入专门的 coding reviewer，还是统一用 Reviewer 角色？ | ✅ 已定 |
| Q4 | 评审结论是否单独存档（projects/{id}/reviews/），还是只记 DISCUSSION-LOG.md？ | ✅ 已定 |

---

## 已定决策

### Q2：模型分档 + Provider 走 newapi-anthropic
- 决策日期：2026-06-13
- Provider：newapi-anthropic（anthropic-messages 格式，支持 prompt caching）。不走 mydamoxing（openai-completions，无缓存）
- 模型分档：
  - 默认档（A类需求/B类规范/D类常规验收）→ newapi-anthropic/claude-sonnet-4-6
  - 高风险档（C类代码/外部API设计/安全相关/关键Skill最终验收）→ newapi-anthropic/claude-opus-4-8
- 落地方式：factory-reviewer agent 默认模型设 sonnet-4-6；高风险评审由 orchestrator spawn 时用 `model` 参数临时覆盖为 opus-4-8
- 待确认：newapi-anthropic 代理是否真的透传缓存折扣计费（建议上线后首批评审验证一次 cacheRead）

### Q1：Reviewer 用独立 agent（方案 A）
- 决策日期：2026-06-13
- 结论：方向定为方案 A（独立 factory-reviewer agent），Evan 同意
- 理由：
  1. 评审灵魂是独立性，复用 orchestrator 身份在结构上保证不了"外部视角/不了解内情"
  2. 模型固定能力——独立 agent 可写死强模型，不靠每次 spawn 传参的纪律
  3. 评审是工厂高频刚需（L1 Step2/7、L2 S3/S5/S7），值得一次性投入做成固定 agent
- 前置条件：落地前必须核实当前 OpenClaw 版本的多 agent + allowlist 机制（见下方待核实）

---

## 待核实事项（OpenClaw 机制，对应核心红线：先研究清楚当前版本提供了什么）

核实来源：本地官方文档 /opt/homebrew/lib/node_modules/openclaw/docs/concepts/multi-agent.md + tools/subagents.md（核实日期 2026-06-13）

| 编号 | 待核实 | 状态 | 结论 |
|---|---|---|---|
| V1 | sessions_spawn(agentId=...) 能否跨 agent 调用 | ✅ 确认可用 | sessions_spawn 的 agentId 参数："Spawn under another agent id when allowed by subagents.allowAgents" |
| V2 | allowAgents 字段确切路径 | ✅ 确认，但路径需修正 | 真实路径是 agents.list[].subagents.allowAgents（每 agent）或 agents.defaults.subagents.allowAgents（默认）。不是顶层 subagents.allowAgents。默认只能 spawn 自己；["*"] 允许任意 |
| V3 | agents.list 多 agent 定义是否稳定 | ✅ 确认稳定 | multi-agent.md 正式文档，每 agent 独立 workspace/agentDir/session store/auth |
| V4 | 独立 agent 如何指定 workspace/模型/runtime | ✅ 确认支持 | agents.list[] 支持 id/workspace/model/agentDir/sandbox/tools/groupChat 等 |

## 🚨 核实中的关键意外发现（影响 Q1 设计）

**F1：Sub-agent 上下文只注入 AGENTS.md + TOOLS.md，不注入 SOUL.md / IDENTITY.md / USER.md / HEARTBEAT.md**
（来源 subagents.md 原文："Sub-agent context only injects AGENTS.md + TOOLS.md"）
- 影响：原计划把 reviewer 人格写进 SOUL.md → 行不通。reviewer 的人格/规则必须写进它 workspace 的 AGENTS.md，或写进 spawn 的 task prompt。
- SOP 草案第 7 节「自己的 SOUL.md」表述需修正。

**F2：spawn 跨 agent 时，目标 agent 的 model 字段生效**
- agents_list 返回每个 agent 的 effective model。factory-reviewer 在 agents.list[] 里写死 model 即可固定强模型，解决模型漂移。（高置信，非每次传参）

**F3：auth 按 agentId 解析，主 agent 的 auth profiles 作为 fallback 合并进来**
- 影响：factory-reviewer 若用 anthropic 模型，可复用 orchestrator 已有的 anthropic auth（fallback 合并），不必单独配。需确认 orchestrator 当前有 anthropic auth。

**F4：orchestrator 必须有 sessions_spawn 工具权限**
- 需 tools.profile 为 coding/full，或 tools.alsoAllow 加 sessions_spawn。messaging profile 默认没有。

**F5：sandbox 限制**
- 若 orchestrator session 被 sandbox，sessions_spawn 会拒绝非 sandbox 目标。需确认 factory 当前 sandbox 状态。

---

## 环境前提核实（2026-06-13，运行配置 = ~/.openclaw/gateways/life/openclaw.json）

| 前提 | 结果 | 说明 |
|---|---|---|
| 当前 agentId | factory-orchestrator | ws=domains/agent-factory，已在 agents.list |
| sandbox | ✅ 未沙箱 | defaults.sandbox=None，factory-orchestrator.sandbox=None → sessions_spawn 不会被拒 |
| sessions_spawn 权限 | ✅ 可用（行为确认） | tools=None 走默认；AGENTS.md 大量依赖 spawn 且实际在跑 |
| 强模型 auth | ✅ 充足 | claude-opus-4-8 有三个 provider：mydamoxing(当前在用)、gsykj-anthropic、newapi-anthropic |
| subagents.maxSpawnDepth | =2 | 支持嵌套，足够 |
| **subagents.allowAgents** | ❌ **未配置** | defaults/factory-orchestrator 都没设 → 当前只能 spawn 自己。落地 A 必须加 factory-reviewer |

## 关键发现（补充）

- **F6**：磁盘上已有 reviewer/claude 等 agent 目录，但 agents.list 里只有 3 个正式 agent（chat-main-agent / quant-orchestrator / factory-orchestrator）。那些目录是历史 sub-agent 残留，不是配置中的 agent。新建 factory-reviewer 是干净的。
- **F7**：claude-opus-4-8 同时挂在 openai-completions(mydamoxing) 和 anthropic-messages(gsykj/newapi) 两类 provider 上 → Q2 模型选型时要决定走哪个 provider（影响稳定性/计费）。

## 下一步

1. ✅ 核实 V1-V4 完成
2. ✅ 环境前提确认完成（唯一待办：落地时加 allowAgents）
3. 逐个讨论 Q2（模型选型，含 provider 选择）、Q3、Q4
4. 全部定稿后统一落地配置 + 转 SOP STABLE
