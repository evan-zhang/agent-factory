# 季报基础模板

> 本文件为季报空模板框架。填写规范见 `../通用填写规范.md`。

## 元数据

```
- 所属项目：TPR-20260327-001
- 节点编号：NODE-001
- 文档类型：TPL
- 文档编号：TPL-001
- 文档标题：季报模板
- 文档状态：DRAFT
- 版本：v1
- 创建时间：2026-03-27
```

---

## 1. 汇报综述

- **[待填写：本季度总体判断]：**
  [填写：整体定调 + 3项成果 + 主要偏差]

- **本季度最关键阶段成果：**
  - 年度财务目标：<p style="text-align: justify;"><strong>收入实现稳健增长与周期均衡，实现131.23亿元人民币含税收入（不含税收入116.44亿人民币）目标</strong></p><p style="text-align: justify;"><strong>各业务单元分解为：</strong></p><table style="width: auto; text-align: start;"><tbody><tr><td colspan="1" rowspan="1" width="286" style="text-align: left;">业务单元</td><td colspan="1" rowspan="1" width="286" style="text-align: left;">营业收入（含税）</td></tr><tr><td colspan="1" rowspan="1" width="286" style="text-align: left;">深康</td><td colspan="1" rowspan="1" width="286" style="text-align: left;">89.09 亿元（含院外23.41亿）</td></tr><tr><td colspan="1" rowspan="1" width="286" style="text-align: left;">德镁</td><td colspan="1" rowspan="1" width="286" style="text-align: left;">21.13 亿元（含院外2.99亿）</td></tr><tr><td colspan="1" rowspan="1" width="286" style="text-align: left;">维盛</td><td colspan="1" rowspan="1" width="286" style="text-align: left;">15.63 亿元（含院外3.94亿）</td></tr><tr><td colspan="1" rowspan="1" width="286" style="text-align: left;">院外连锁驱动的业务</td><td colspan="1" rowspan="1" width="286" style="text-align: left;">0.38 亿元（院外业务合计30.83亿）</td></tr><tr><td colspan="1" rowspan="1" width="286" style="text-align: left;">其他：美馨/天康/康联达</td><td colspan="1" rowspan="1" width="286" style="text-align: left;">美馨2.30 亿元、天康1.93亿元（含院外0.11亿）、康联达 0.76亿；小计4.99亿</td></tr></tbody></table><p><br></p>
- 价值重构：优化业务与市场结构：<p><strong>启动业务组合优化，明确各业务单元成长型/成熟型产品划分</strong></p>
- 体系运营：提升运营效率与管理水平：<p><strong>构建线上化、标准化、智能化的核心业务流程体系。</strong></p>

- **本季度最主要偏差：**
  [填写：2-3项 + 当前状态]

- **对下季度的总体策略判断：**
  [填写：策略重点]

---

## 2. BP目标承接与对齐情况

### 2.1 [年度财务目标]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">每半年实现不含税销售额与毛利的环比增长，确保“双环”目标实现（金额波动率＜2%）。</span></p><table style="width: auto;"><tbody><tr><td colSpan="1" rowSpan="1" width="63"></td><td colSpan="1" rowSpan="1" width="119">销售额</td><td colSpan="1" rowSpan="1" width="112">销售额<br>环比增长</td><td colSpan="1" rowSpan="1" width="122">毛利</td><td colSpan="1" rowSpan="1" width="122">毛利<br>环比增长</td></tr><tr><td colSpan="1" rowSpan="1" width="63">H1</td><td colSpan="1" rowSpan="1" width="119">60.80亿</td><td colSpan="1" rowSpan="1" width="112">13.72%</td><td colSpan="1" rowSpan="1" width="122">33.35亿</td><td colSpan="1" rowSpan="1" width="122">13.51%</td></tr><tr><td colSpan="1" rowSpan="1" width="63">H2</td><td colSpan="1" rowSpan="1" width="119">70.43亿</td><td colSpan="1" rowSpan="1" width="112">15.84%</td><td colSpan="1" rowSpan="1" width="122">38.84亿</td><td colSpan="1" rowSpan="1" width="122">16.46%</td></tr><tr><td colSpan="1" rowSpan="1" width="63">全年</td><td colSpan="1" rowSpan="1" width="119">131.23亿</td><td colSpan="1" rowSpan="1" width="112">24.76%</td><td colSpan="1" rowSpan="1" width="122">72.19亿</td><td colSpan="1" rowSpan="1" width="122">25.50%</td></tr></tbody></table><p><br></p>

**当前状态：**
- 量化指标：>60.80, >13.72%, >33.35, >13.51%, >70.43, >15.84%, >38.84, >16.46%, >131.23, >24.76%, >72.19, >25.50%
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.2 [价值重构：优化业务与市场结构]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p><strong>完成集团成长型产品竞争力评估</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">（基于麦肯锡GE模型），并6个月输出首版产品地图</span></p>

**当前状态：**
- 量化指标：6个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.3 [体系运营：提升运营效率与管理水平]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><strong>以打通业务断点、实现全流程线上运营管理为先导，夯实数字化基础。</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">在此基础上，推动流程标准落地，并建设嵌入核心场景的AI能力平台，全面支撑运营效能跃升。核心业务指标包含：</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51);">· </span><strong>覆盖广度：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">实现关键业务流程线上化率 </span><span style="font-family: 微软雅黑;">≥100</span><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">%（完成集团定义的2026年需要完成的关键业务流程）；</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51);">· </span><strong>运行效率：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">核心业务行为的端到端平均处理周期缩短</span><span style="color: rgb(51, 51, 51); background-color: rgb(245, 219, 77); font-family: 微软雅黑;">【*】%；</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51);">· </span><strong>终极价值：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">在此基础上，驱动销售团队人均营收提升&gt;</span><span style="color: rgb(51, 51, 51); background-color: rgb(245, 219, 77); font-family: 微软雅黑;">【*】%。</span></p>

**当前状态：**
- 量化指标：≥100
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.4 [创新自立：强化自主创新能力]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. </span><strong>确立投入基线</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">：计划年度总研发投入(含资本化投入)占不含税营收比重 18% - 23%。</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">2. </span><strong>优化投入结构</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">：以上述总投入为基线，进行战略性分配：</span></p><ul><ul><li style="text-align: justify;"><strong>自主研发</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">：投入占比不低于25%，保障长期技术自立。</span></li><li style="text-align: justify;"><strong>国内合作</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">：投入占比约为35%，用于开放式创新与生态构建。</span></li><li style="text-align: justify;"><strong> 海外引进：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">投入占比约为40%，聚焦于全球前沿技术的快速转化。</span></li></ul></ul><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">3. </span><strong>健全管理机制</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">：建立从预算编制、审批、执行监控到效果评估的全流程闭环管理体系，确保每一板块的投入均与相应的战略目标、项目里程碑及产出要求严格挂钩，实现资源精准、高效配置，3个月完成。</span></p>

**当前状态：**
- 量化指标：>1., >2., >3., 3个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.5 [组织跃迁：打造高效组织体系]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="font-family: 微软雅黑;">1. </span><strong>定义标准：</strong><span style="font-family: 微软雅黑;">依据集团战略与关键业务流程，明确关键岗位的胜任力模型与资质要求，</span><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">9个月完成。</span></p><p style="text-align: justify;"><span style="font-family: 微软雅黑;">2. </span><strong>盘点与规划：</strong><span style="font-family: 微软雅黑;">完成100%关键岗位人才盘点，识别差距，并制定“一人一策”的针对性发展/补给计划，</span><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">12个月完成。</span></p><p style="text-align: justify;"><span style="font-family: 微软雅黑;">3. </span><strong>动态补充：</strong><span style="font-family: 微软雅黑;">确保年度核心人才引进目标达成率≥</span><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">90</span><span style="font-family: 微软雅黑;">%，核心人才保留率≥</span><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">90</span><span style="font-family: 微软雅黑;">%，持续优化人才结构，</span><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">12个月初步运行。</span></p>

**当前状态：**
- 量化指标：>1., >9, >2., >12, >3., >90, >90, >12, 9个, 12个, 12个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.6 [韧性防线：构建风险防控体系]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="font-family: 微软雅黑;">1. </span><strong>风险预警机制化：</strong><span style="font-family: 微软雅黑;">建立并运行“监测-预警-评估”线上化流程。由审计部主导、信息技术部支持，建立核心业务风险指标库与预警模型；法务部负责法律与政策风险研判；合规部负责合规风险扫描；财经中心负责财务风险监控；人力资源中心负责组织与用工风险预警。确保核心业务领域风险预警覆盖率达到100%，前瞻性预警比重≥80%，12个月完成。</span></p><p style="text-align: justify;"><span style="font-family: 微软雅黑;">2. </span><strong>应急响应协同化：</strong><span style="font-family: 微软雅黑;">建立重大风险事件应急协同流程。合规部牵头协调，经营管理中心负责业务端紧急处置与稳定；法务部提供法律支持；财经中心负责资金与资产风险应对；审计部介入独立调查。确保重大风险事件平均响应与介入时效≤12小时，6个月完成。</span></p><p style="text-align: justify;"><span style="font-family: 微软雅黑;">3. </span><strong>处置闭环责任化：</strong><span style="font-family: 微软雅黑;">建立风险整改跟踪与问责机制。由法务部主导处置的法律闭环与问责；审计部负责整改效果的独立验证；合规部监督流程合规性；经营管理中心与财经中心负责业务与财务整改落实；人力资源中心依据结果落实人员问责或激励。确保已识别风险的处置闭环率达100%，6个月完成。</span></p>

**当前状态：**
- 量化指标：>1., ≥80%, >2., ≤12, >3., 12个, 6个, 6个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.7 [产品力发展战略：构建以临床价值与商业成功为导向的领先产品矩阵]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. </span><strong>价值输出目标（产品上市）</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">：确保每年有新产品上市，形成稳定现金流。年度目标：保底5分、基线7分、卓越9分。</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">2. </span><strong>管线输入目标（合作引入）</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">：通过海外许可与合作开发（3.0模式），快速强化优势领域管线。年度目标：保底7分、基线9分、卓越12分。</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">3. </span><strong>管线输入目标（自主研发）</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">：通过自主研发（4.0模式），布局下一代核心产品。年度目标：保底10分、基线15分、卓越20分。</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">4. </span><strong>战略聚焦目标（领域卡位）</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">：年内完成在至少3个优势病种的产品矩阵部署，构建国内核心竞争优势。具体部署方向：</span></p><ul><ul><li style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">深康：心肾代谢、消化与肝病、中枢神经与精神（心血管、消化与肝病优先）。</span></li><li style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">德镁：皮肤领域为核心，拓展血管外科；消费健康领域发展皮肤学级护肤品。</span></li><li style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">维盛：眼科、耳鼻喉。</span></li><li style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">院外：覆盖核心治疗领域，并拓展契合院外模式的自主健康产品矩阵。</span></li></ul></ul>

**当前状态：**
- 量化指标：>1., >2., >3., >4., 3个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.8 [现代化商业化体系建设：打造以产品价值最大化为核心的敏捷高效商业平台]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. </span><strong>产品引进评估与上市成功率保障：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">建立基于集团优势治疗领域的产品引进评估标准与决策流程，确保新品符合战略定位。对获批产品，严格执行“六位一体”协同的标准化上市流程，确保新品上市首年目标达成率不低于预设基准，3个月完成。</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">2. </span><strong>成熟产品精细增长与患者运营：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">针对核心产品，实施基于患者旅程的全渠道增长策略。建立“一产品一策略”的管理模式，通过潜力市场挖掘、患者教育与管理、渠道精耕等组合策略，保障慢病产品销售额达成年度增长目标，3月完成。</span></p>

**当前状态：**
- 量化指标：>1., >2., 3个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.9 [同心多元化战略：构建以院外市场为核心的第二增长引擎]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. </span><strong>业务框架标准化：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">发布官方的院外业务分类与统计标准，统一各板块（尤其是新媒体B2C/OTO业务）的收入、成本、利润核算规则，3个月完成。</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">2. </span><strong>业务算法与监控体系：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">建立关键业务算法（如铺货效率、患者流转率、内容转化率等）和实时数据监控看板，实现对四大板块经营状况的动态跟踪与预警，3个月完成。</span></p>

**当前状态：**
- 量化指标：>1., >2., 3个, 3个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.10 [产业国际化战略]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(0, 0, 0); background-color: rgb(191, 191, 191);"><em>1. 启动打造辐射亚太地区的核酸药物研发与转化核心枢纽。</em></span></p><p style="text-align: justify;"><span style="color: rgb(0, 0, 0); background-color: rgb(191, 191, 191);"><em>2. 挖掘与新加坡国家平台（如A-STAR、NUS、NTU）的实质性合作项目，对接基础研究与产业化需求。</em></span></p>

**当前状态：**
- 量化指标：>1., >2.
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.11 [供应链价值创造战略：构建敏捷、可靠、高效的战略性供应体系]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. </span><strong>全景式供应地图与预案：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">完成所有在售及即将上市核心产品的“供应地图”绘制，明确各环节产能、所在地及单一依赖点，并制定相应的多源供应或技术转移预案，</span>6月前完成初步要素及需求梳理，9月完善并按季度更新，12月前系统上线。</p><p style="text-align: justify;">2. <strong>动态风险监控与应急机制：</strong><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">建立供应链风险的定期排查、评估与动态监控机制。设立明确的库存安全红线（如总仓库存不低于90天安全库存），并制定分级应急响应流程，确保重大供应风险零发生，</span><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">12月完成。6月前完成初步要素及需求梳理，9月完善并按季度更新，12月前系统上线。</span></p>

**当前状态：**
- 量化指标：>1., >6, >2., >12
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.12 [战略投资收益战略]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="background-color: rgb(191, 191, 191);"><em>建立健全投资闭环管理机制，重点完善退出管理机制，年度投资利润达成 ≥</em></span><span style="color: rgb(51, 51, 51); background-color: rgb(191, 191, 191); font-family: 微软雅黑;">XX</span><span style="background-color: rgb(191, 191, 191);"><em>亿元人民币，投资组合整体投资收益率（IRR）≥25%？</em></span><em> </em></p>

**当前状态：**
- 量化指标：≥25%
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.13 [体系化建设保障]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. 核心业务流程标准化覆盖率 ≥50%。</span></p><p style="text-align: justify;"><span style="font-family: 微软雅黑;">2. 核心制度系统固化率启动建设并完成初步规划</span><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">，6个月完成</span><span style="font-family: 微软雅黑;">。</span></p>

**当前状态：**
- 量化指标：>1., ≥50%, >2., 6个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.14 [组织力与价值分配保障]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">完成网络型组织重构，建立组织健康度评估模型，确保架构调整（如院外、研发体系）支撑核心业务，并具备清晰的价值评估基础，12个月完成。</span></p>

**当前状态：**
- 量化指标：12个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.15 [信息化建设保障]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. 建立健全信息化项目管理机制，确保完成战略管理系统、文件系统、云平台系统按顶层规划上线运行，按1-2个月频率推出推广“+1”级AI应用轻量级工具，12个月完成。</span><span style="font-family: 微软雅黑;"> </span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">2. 完成业务流程“断点”修复与数据治理工作，确保各业务部门100%线上操作，线下Excel传递清零，12个月完成。</span><span style="font-family: 微软雅黑;"> &nbsp;</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">3. 建立业务数据清单及指标库，各业务板块搭建业务BI看板及AI智能助手，12个月完成。</span></p>

**当前状态：**
- 量化指标：>1., >2., >3., 2个, 12个, 12个, 12个
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.16 [资本保障]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. 完善市值管理：确保集团总市值维持在健康水平，2026年康哲药业（剔除德镁）实现大于300 亿港元市值目标，德镁上市后市值大于150亿港元。</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">2. 德镁通过资本市场融资大于10亿港元</span></p>

**当前状态：**
- 量化指标：>1., >2.
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.17 [生产保障]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. 启动核心产品自主生产能力建设，目标三年内建成。</span><span style="font-family: 微软雅黑;"> </span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">2. 启动国际标准质量体系建设，目标三年内建成。</span></p>

**当前状态：**
- 量化指标：>1., >2.
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]

### 2.18 [法律与合规保障]

**对标BP：** [对应个人BP编码]（个人）/ [待确认编码]（组织）

**本季度承接重点：**
- <p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">1. 内控审计项目工作100%遵循质量控制程序。</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">2. 风险管理覆盖率与合规培训覆盖率均达到100%。</span></p><p style="text-align: justify;"><span style="color: rgb(51, 51, 51); font-family: 微软雅黑;">3. 公司维持、知识产权维持0重大法律风险，证券事务维持0法律风险；重大合规事件发生数为0。 </span></p>

**当前状态：**
- 量化指标：>1., >2., >3.
- 偏离判断：[红/黄/绿]

**是否偏离预期：**
- [是/否]，[偏离率]
## 3. 核心结果与经营表现

### 重点事项1
- 对应 BP：[编码]
- 季度目标：[数字]
- 阶段成果：[数字]
- 指标完成情况：[描述]
- 当前状态：[红/黄/绿]
- 阶段判断：[达成/基本达成/偏离]

---

## 4. 关键举措推进情况

- 本季度关键举措清单：[列表]
- 已完成举措：[描述]
- 推进中举措：[描述]
- 延迟/失效举措：[描述]
- 举措对成果的支撑判断：[描述]

---

## 5. 问题、偏差与原因分析

- 本季度主要偏差：[量化描述]
- 偏差分类：[目标问题/成果问题/举措问题/协同问题/资源问题]
- 结构性原因：[分析]
- 是否影响年度达成：[是/否]

---

## 6. 风险预警与资源需求

- 下季度前的主要风险：[描述]
- 对应 BP：[编码]
- 预警等级：[红/黄/绿]
- 需调整资源：[描述]
- 需推动协同：[描述]

---

## 7. 下季度重点安排

### 7.1 下季度重点目标
[填写：3-5项量化目标]

### 7.2 下季度关键成果
[填写：对应BP + 预期成果]

### 7.3 下季度关键举措
[填写：每项对应一个BP编码]

### 7.4 需校准事项
[填写：本季度偏差在Q2的修正方案]

---

## 8. 需决策/需协同事项

- 需决策事项：[描述]
- 需跨部门协同事项：[描述]
- 需上级关注事项：[描述]
- 如无：本期无
