---
name: cms-meeting-materials
description: CMS 会议素材镜像能力（会记/慧记/会议纪要）：基于 appKey 自动发现可访问会议或使用已知 meetingChatId，拉取并持续同步会议转写文本到本机共享目录（~/.openclaw/cms-meeting-materials/{gateway}/{meetingChatId}）。用于为后续总结/问答/纪要技能提供标准化原始素材。
skillcode: cms-meeting-materials
---

# AI慧记

**当前版本**: v1.10.7

> **AI慧记** 提供三类核心能力：
> 1. **📋 查询列表** — 从「我的慧记」或「视频会议号」两个维度查询会议记录
> 2. **📄 获取原文** — 拿到转写原文作为分析素材（支持全量 / 增量 / 改写三种模式）
> 3. **🧠 AI 分析** — 基于原文进行总结、待办提取、专题分析
> 4. **🔴 会中实时模式** — 会议进行中实时增量消费转写文本，提供 T+3s 速记流和 T+45s 滚动摘要

---

## 能力概览

| # | 接口 | 路径 | 说明 |
|---|---|---|---|
| 1 | chatListByPage | /ai-huiji/meetingChat/chatListByPage | 分页查询我的慧记列表（归属维度） |
| 2 | listHuiJiIdsByMeetingNumber | /ai-huiji/meetingChat/listHuiJiIdsByMeetingNumber | 按视频会议号查询慧记列表（会议维度） |
| 3 | splitRecordList | /ai-huiji/meetingChat/splitRecordList | 全量查询分片转写原文 |
| 4 | splitRecordListV2 | /ai-huiji/meetingChat/splitRecordListV2 | 增量查询分片转写原文 |
| 5 | checkSecondSttV2 | /ai-huiji/meetingChat/checkSecondSttV2 | 已结束会议的改写原文（更高质量，可能有发言人） |

---

## 鉴权

所有接口只需 `appKey`（环境变量 `XG_BIZ_API_KEY`），无需用户登录态，也**不依赖 cms-auth-skills**。

---

## 快速开始（1分钟）

```bash
# 1) 设置 API Key（当前 shell 生效）
export XG_BIZ_API_KEY='你的 appKey'

# 2) 验证可访问会议（成功返回列表即鉴权可用）
python3 scripts/huiji/list-my-meetings.py 0 5 --json

# 3) 已知会议号时，直接查询会议维度记录
python3 scripts/huiji/list-by-meeting-number.py <meetingNumber> --json
```

> 若返回“请设置环境变量 XG_BIZ_API_KEY”，说明当前进程尚未加载环境变量。

---

## 意图路由表

### 📋 列表查询

| 用户说 | 路由 | 说明 |
|---|---|---|
| "我的慧记" / "我的会议纪要" / "最近有什么会议" | **4.1** chatListByPage | 归属维度，无需会议号 |
| "会议号 xxx" / "这场会议的纪要"（提供了会议号时） | **4.11** listHuiJiIdsByMeetingNumber | 会议维度，需要会议号 |
| "帮我找 xxx 的会议" / "搜索 xxx" | **4.1** chatListByPage + nameBlur | 搜索模式 |
| "进行中的会议" / "正在开的会" | **4.1** chatListByPage `--state 0` | 进行中，一条命令搞定 |
| "历史会议" / "已结束的会议" | **4.1** chatListByPage `--state 2` | 历史，一条命令搞定 |

### 📄 原文获取

| 用户说 | 路由 | 说明 |
|---|---|---|
| "这个会议的原文" / "会议内容" / "转写" | **get-transcript.py** | 统一入口，自动处理全量/增量/改写 |
| "最新的" / "刚才说的" / "最近几分钟的" | **get-transcript.py** | 自动增量拉取最新内容 |

### 🧠 AI 分析

| 用户说 | 能力 | 说明 |
|---|---|---|
| "总结一下" / "会议纪要" / "概要" / "说了什么" | 📝 会议总结 | 基于原文生成结构化纪要 |
| "有什么待办" / "谁负责什么" / "跟进事项" | ✅ 待办提取 | 从原文中提取待办 |
| "关于 xxx 讨论了什么" / "财务那块" | 🔍 专题分析 | 按主题提取相关内容 |

### 🔴 会中实时

| 用户说 | 命令 | 说明 |
|---|---|---|
| "开始实时监控" / "实时跟踪这场会议" | `start-stream <meetingChatId>` | 启动会中实时流 |
| "停止监控" / "不用跟踪了" | `stop-stream` | 停止实时流 |
| "当前监控状态" | `stream-status` | 查看监控中的会议 |

---

## 列表查询详解

### 两个维度的区别

| 维度 | 接口 | 口径 | 适用场景 |
|---|---|---|---|
| **归属维度** | 4.1 chatListByPage | 查「我的」慧记（归属在当前用户名下的记录） | 浏览自己的纪要、搜索、筛选 |
| **会议维度** | 4.11 listHuiJiIdsByMeetingNumber | 按「我参加的视频会议」查（即使他人录制也可查到） | 已知会议号、查找特定会议的纪要 |

### 路由规则（⚠️ 必须严格遵守）

```
用户提供了会议号？
  ├─ 是 → 4.11（按会议号精确查）
  └─ 否 → 4.1（走归属维度查询）
```

**⚠️ 常见错误：用户说"我的进行中会议"但 AI 跳过 4.1 直接用了 4.11 + 上下文中记的会议号。这是错误的。没有明确会议号时必须走 4.1。**

**⚠️ `lastTs` 默认值**：调用 4.11 时**必须传 `lastTs`**，默认限制为**最近 10 天**（`当前时间 - 10天` 的毫秒时间戳），避免返回过多无关记录。除非用户明确要求查更早的记录，否则一律带上此参数。

### 按状态查询（⚠️ 一步到位）

脚本已内置 `--state` 参数，**一次 API 调用 + 客户端过滤**，不要分多次查询：

```bash
# 进行中的会议（一条命令，无需二次查询）
python3 chat-list-by-page.py --human --state 0 0 10

# 已完成的会议
python3 chat-list-by-page.py --human --state 2 0 10
```

> 接口默认按 `updateTime` 倒序，进行中的会议必然排在最前面，`pageSize: 10` 绰绰有余。不需要额外加时间范围或多次查询。

### 无结果引导（⚠️ 必须执行）

当用户查询列表（4.1）未找到任何结果时，AI 应主动引导：

- **4.1 查无进行中会议**：提醒用户"归属维度没有找到你名下的进行中会议。如果你正在参加别人发起/录制的会议，请提供会议号，我按会议号帮你查。"
- **4.1 查无任何会议**：提醒用户"归属维度没有找到记录。如果你参加的是他人录制的会议，请提供会议号试试。"

> **原因**：4.1 只查归属在当前用户名下的记录，不包含用户仅"参加"但非"发起/录制"的会议。4.11 覆盖范围更广（按会议号查所有参与过的记录），但需要用户主动提供会议号。

### 会议状态判断

- **4.1 返回** `combineState`: `0` = 进行中, `1` = 处理中, `2` = 已完成, `3` = 失败
- **4.11 返回** `open`（是否开启）+ `isDoneRecordingFile`（录音是否完成）组合判断

---

## 原文获取策略

这是本 Skill 的核心逻辑。AI 在需要获取会议原文时，**只需调用一个脚本**：

```bash
python3 scripts/huiji/get-transcript.py <meetingChatId> [--name "会议名称"]
```

脚本自动处理全量/增量切换、缓存读写、二次改写，AI **不需要**直接调用 4.4 / 4.10 / 4.8 接口。

### 统一脚本工作流程

```
用户请求会议原文
  │
  ├─ _final 缓存存在？ → 直接返回（二次改写，最优质量）✅
  │
  ├─ _live 缓存标记 completed？ → 尝试拉 checkSecondSttV2
  │     ├─ state=2 成功 → 写入 _final 缓存 → 返回
  │     └─ state=1/3 未就绪 → 返回 _live 缓存
  │
  ├─ _live 缓存存在？ → 4.10 增量拉取 → 合并到 _live
  │
  └─ 无缓存 → 4.4 全量拉取 → 写入 _live 缓存
```

### 双缓存机制

| 缓存文件 | 来源 | 质量 | 说明 |
|---|---|---|---|
| `{id}_live.json` | 4.4 + 4.10 | 实时转写 | 进行中会议的增量数据 |
| `{id}_final.json` | checkSecondSttV2 | 二次改写 | 已结束会议的最优数据（可能有发言人） |

**质量优先级**：`_final`（改写） > `_live`（实时） > 全量拉取

### 输出 JSON 结构

```json
{
  "source": "full | incremental | cache_live | cache_final | second_stt",
  "meetingChatId": "xxx",
  "name": "会议名称",
  "status": "ongoing | completed",
  "lastSyncAt": 1716349200000,
  "lastStartTime": 120034,
  "fullText": "拼接好的全文...",
  "fragments": [...]
}
```

`source` 字段说明当前数据来源，AI 可据此判断数据新鲜度，但**不需要向用户暴露此信息**。

### ⚠️ 防丢失保障

- **原子写入**：先写临时文件再 rename，防止写入崩溃损坏缓存
- **自动备份**：每次写入前备份旧缓存为 `.bak`
- **增量校验**：合并后分片数不能比旧缓存少，否则保留旧数据并输出 warning
- **去重策略**：同 startTime 保留 text 更长的版本，防止截断覆盖

---

## AI 分析能力

拿到原文后，AI 根据用户意图提供以下分析。所有分析基于原文内容，不依赖平台预生成的报告或待办。

### 📝 会议总结

**触发**："总结一下"、"会议纪要"、"概要"、"说了什么"

**输出结构**：
- **会议主题**：一句话概括
- **讨论要点**：按议题分段，每段包含核心观点和关键信息。有发言人信息时标注谁说了什么
- **决策/结论**：达成的共识和决定
- **遗留问题**：未解决的事项

**注意事项**：
- 进行中会议必须明确告知"这是截至目前的内容，会议仍在进行中"
- 优先使用 4.8 改写原文（有发言人区分）
- 原文较长时，分段总结后合并，避免遗漏

**⚠️ 严格约束：防幻觉与术语准确性**

原文由语音转文字生成，AI 在总结/待办提取/专题分析时必须遵守以下原则：

1. **禁止虚构以下任何信息**：
   - ❌ 时间信息：会议时间、截止时间、时间节点等
   - ❌ 人物信息：参会人员、负责人、相关人员等
   - ❌ 具体数据：数字、数量、百分比等
   - ❌ 决策结论：会议决策、结论、判断等
   - 只能总结和提炼会议内容中明确提到的信息
   - 所有引用的信息必须能在原始会议内容中找到对应依据

2. **专业术语智能纠错**：
   - 药品名称、疾病名称、医学术语、公司名称等专业领域术语，结合上下文判断是否为语音识别错误（同音字、近音字）
   - 同一术语在报告中统一使用正确标准表述
   - ⚠️ 仅纠正有把握确认的明显错误，无法确定时保持原文，不要臆测

3. **归纳需诚实标注**：
   - AI 归纳的框架名称、分类体系、流程总结等，需标注"AI 根据会议内容归纳"或类似说明
   - 区分"原文原话"和"AI 的归纳提炼"
   - 零散发言拼凑的时间线/决策链，需如实说明"根据多次讨论综合"

### ✅ 待办提取

**触发**："有什么待办"、"谁负责什么"、"跟进事项"

**输出格式**：
- 每条待办：`[待办内容] → [责任人] → [截止时间/优先级]`
- 无法从原文确认的部分标注 ⚠️ 待确认
- 区分「明确分配的待办」和「讨论中未定的事项」
- 按优先级或提及顺序排列
- ⚠️ 待办的责任人、截止时间必须严格来自原文，不可推测或默认

### 🔍 专题分析

**触发**："关于 xxx 讨论了什么"、"财务那块说了什么"

**输出**：
- 相关讨论内容的摘要
- 涉及的发言人（如有）
- 对应的大致时间位置（如"会议中段"、"后半段"）
- 关联的决策或待办（如有）

---

## 本地缓存机制

### 缓存目录

```
ai-huiji/.cache/huiji/
```

### 双缓存文件

| 文件 | 命名 | 说明 |
|---|---|---|
| 实时缓存 | `{meetingChatId}_live.json` | 进行中会议（4.4 + 4.10） |
| 改写缓存 | `{meetingChatId}_final.json` | 已结束会议（checkSecondSttV2，最优质量） |

两份数据格式相同：

```json
{
  "meetingChatId": "xxx",
  "name": "产品周会",
  "status": "ongoing | completed",
  "source": "full | incremental | second_stt | cache_live | cache_final",
  "lastSyncAt": 1716349200000,
  "lastStartTime": 120034,
  "fullText": "拼接好的全文...",
  "fragments": [
    { "startTime": 0, "text": "第一段内容...", "realTime": 1716345600000 },
    { "startTime": 120034, "text": "第二段内容...", "realTime": 1716345720000 }
  ]
}
```

### 字段说明

| 字段 | 说明 |
|---|---|
| `meetingChatId` | 会议 ID |
| `name` | 会议名称（来自列表或 `--name` 参数） |
| `status` | `ongoing`（进行中）/ `completed`（已结束） |
| `source` | 数据来源标识 |
| `lastSyncAt` | 上次同步的 Unix 毫秒时间戳 |
| `lastStartTime` | 4.10 增量查询的游标（分片的 startTime 值） |
| `fullText` | 按 startTime 排序拼接的完整转写文本 |
| `fragments` | 全部分片明细（startTime / text / realTime） |

### 缓存策略

- 用户每次请求会议原文时，`get-transcript.py` 自动管理缓存
- **进行中会议**：增量更新（4.10 + `lastStartTime`），合并到 `_live`
- **已结束会议**：`_live` 标记 completed 后自动尝试拉改写，成功写入 `_final`
- 缓存无自动过期，由 AI 在必要时清理或用户主动清理
- ⚠️ AI **不需要**直接操作缓存文件，统一通过 `get-transcript.py` 管理
- **自动清理**：每次运行时自动清理超过 15 天的过期缓存（已结束会议 + 共享资料）

---

## 共享资料机制

多用户可以针对同一场会议共享分析资料，供其他人查看和讨论。

### 共享目录结构

```
.cache/huiji/shared/
└── {meetingNumber}/           # 按会议号隔离
    └── {yyyyMMdd}/            # 按天隔离
        ├── 184500_王晓辉_林总发言总结.md
        ├── 185200_成伟_AI训练方案.md
        └── ...
```

### 共享文件格式

```markdown
---
meetingNumber: 103760
meetingChatId: huijiXgMt_69c8cc89a61e5c000a9f8b72
author: 王晓辉
created: 2026-03-29 18:45:00
---

## 正文内容...
```

### 使用规则

1. **用户明确说"共享"时才写入**，不自动共享
2. **写入前必须确认**：告知用户即将共享的内容摘要和文件名
3. **文件名规范**：`{HHmmss}_{人名}_{原始标题}.md`，标题必须用原始标题，不额外处理
4. **查询时自动发现**：AI 在查询某场会议时，应检查 `shared/{meetingNumber}/` 目录，如有共享资料需主动提示用户
5. **读取共享**：用户说"看看有什么共享资料"或"分析下XX的那个总结"时，从对应目录读取
6. **时效性**：共享资料超过 15 天自动清理（与缓存同步清理）

### 典型场景

| 用户说 | AI 行为 |
|---|---|
| "把这个分析共享给其他人" | 写入 shared/{meetingNumber}/{yyyyMMdd}/ |
| "103760有什么共享资料" | 列出 shared/103760/ 下的所有文件 |
| "分析下王晓辉刚才的那个总结" | 从 shared/{meetingNumber}/ 下找到对应文件并读取分析 |

---

## _id 透明处理（对 AI 可见）

4.1 返回的 `_id` 可能有 `__数字` 后缀（如 `abc123__45678`），不能直接用作 `meetingChatId`。

标准处理：
- 优先使用 `originChatId`；
- 若无 `originChatId` 且 `_id` 含 `__`，截取前缀作为 `meetingChatId`；
- 若均无特殊情况，直接使用 `_id`。

`list-my-meetings.py --json` 已透明输出：
- `rawId`：原始 `_id`
- `originChatId`
- `normalizedMeetingChatId`
- `idNormalizationApplied`（是否发生归一化）

文本模式下，仅当发生 `__` 后缀截断时，会额外显示：
`ID 归一化: <rawId> -> <meetingChatId>`

---

## 时间戳处理规范（⚠️ 必须严格遵守）

所有接口返回的时间字段均为 **13 位毫秒级 Unix 时间戳**（如 `1774763950431`）。

### 转换规则

```
毫秒时间戳 → 秒：除以 1000（1774763950431 / 1000 = 1774763950.431）
秒 → 本地时间：UTC+8（Asia/Shanghai）
```

### 展示规则

**向用户展示时，必须将时间戳转换为人类可读格式**，禁止直接展示原始数字。

- **日期时间**：`2026-03-29 13:59:10`
- **仅日期**：`2026-03-29`
- **仅时间**：`13:59`
- **时长**：毫秒转分钟 → `7624789 ms ≈ 127 分钟 ≈ 2小时7分钟`

### 转换示例

| 原始值（毫秒时间戳） | 转换结果 |
|---|---|
| `1774763950431` | `2026-03-29 13:59:10` |
| `1774704179623` | `2026-03-28 22:42:59` |
| `7624789`（meetingLength，毫秒） | `2小时7分钟` |

### 分片时间戳

- `realTime`：现实时间戳（毫秒），转换为绝对时间展示
- `startTime`（4.4/4.10）：录音内偏移量（毫秒），转换为 `00:12:34` 格式的录音内时间点

---

## 多环境部署

本 Skill 可部署在任意 OpenClaw / EasyClaw 环境中。脚本调用使用相对于 SKILL.md 的路径：

```
scripts/huiji/<脚本名>.py
```

OpenClaw 在加载 Skill 时会将完整路径注入上下文，AI 直接拼接使用即可，无需硬编码绝对路径。

---

## 会中实时模式（v1.10.1 新增，v1.10.2 增强）

> **核心定位**："会中优先、会后兼容"的会议语义流处理器。用户在会议进行中即可实时看到转写内容，无需等待会议结束。

### 架构概览

```
慧集平台 API
    │
    ▼
poll-scheduler.py（自适应轮询调度）
    │
    ▼
stream-sync.py（增量拉取 + checkpoint）
    │
    ├─ 新片段 → APPEND 事件
    ├─ 二次转写完成 → REPLACE 事件
    │
    ▼
event-processor.py（语义处理）
    │
    ├─ 实时速记流（T+3s）
    ├─ 滚动摘要（T+45s 触发）
    └─ 会后纪要（会议结束后）
```

### 启动条件

满足以下任一条件时，AI 可主动建议启动实时模式：

1. 用户说"开始实时监控这场会议"、"实时跟踪"、"会中监控"
2. 用户查询"进行中的会议"后，AI 发现有正在进行的会议，可主动询问"是否要实时跟踪这场会议？"
3. 用户说"这场会议在说什么"且会议尚未结束

### 实时速记流（T+3s）

- 会议启动后，每 **2-8 秒**（自适应间隔）增量拉取新分片
- 新文本在 **3 秒内**展示给用户
- 展示格式：按时间顺序，标注说话时间段
- 不向用户暴露"轮询"、"增量拉取"、"SQLite"等技术过程，只展示转写内容
- **二次转写到达时**：静默替换旧文本，旧文本标注"已校正"，不打断用户阅读

### 滚动摘要（T+45s）

- 每 **45 秒**自动更新一次结构化摘要卡片
- 卡片包含：
  - **议题关键词**：当前讨论的高频词/主题（基于词频自动提取）
  - **决策记录**：包含"决定/确定/同意/通过/批准"等关键词的句子
  - **行动项列表**：匹配"[人名]负责/跟进/提交/完成/处理[事项]"的待办
- 摘要使用内置轻量引擎（纯正则+词频），不依赖外部 LLM API，始终可用
- 摘要持久化到本地 SQLite，重启后不丢失
- 使用 `stream-status <meetingChatId>` 可随时查看最新摘要
- 用户可随时说"总结一下"主动触发

### 会后自动切换

- 检测到会议结束（combineState=2）→ 自动切换到会后模式
- 生成完整纪要（继承会中所有修正内容）
- 不需要用户额外操作

### 实时流命令

| 命令 | 说明 | 示例 |
|---|---|---|
| `start-stream <meetingChatId>` | 启动一场会议的实时监控 | `start-stream huijiXgMt_abc123` |
| `stop-stream <meetingChatId>` | 停止指定会议的监控 | `stop-stream huijiXgMt_abc123` | 
| `stream-status` | 查看当前所有监控流状态 | `stream-status` |

### 事件模型

| 事件类型 | 触发条件 | 幂等键 |
|----------|----------|--------|
| APPEND | 新增分片（startTime > lastStartTime） | meeting_chat_id + segment_id + version=1 |
| REPLACE | 二次转写完成（checkSecondSttV2 state=2） | meeting_chat_id + segment_id + version=2 |
| DELETE | 平台标记删除 | meeting_chat_id + segment_id |

### 自适应轮询策略

| 场景 | 轮询间隔 |
|------|----------|
| 近 10 秒有新片段（活跃） | 2 秒 |
| 30 秒无新片段（静默） | 8 秒 |
| 连续 3 次失败（断连） | 指数退避：2→4→8→16→30s（上限） |
| 断连恢复后 | 全量校验：对比本地 vs 远端片段数，补发缺失 |

### 技术实现要点

- **存储**：SQLite 本地数据库（`huiji_stream.db`），不引入 Redis/MySQL
- **事件表**：`events`（幂等键 UNIQUE）+ `checkpoints`（游标）+ `summaries`（摘要缓存）
- **同时监控上限**：≤ 3 场会议（超出时提示用户先停止一场）
- **向后兼容**：现有会后模式（get-transcript.py / AI 分析）不受影响

### ⚠️ 严格约束（沿用会后模式）

1. **隐藏技术细节**：用户只看到转写内容和摘要，不暴露轮询/数据库/事件等技术过程
2. **防幻觉**：实时流内容直接来自平台转写，摘要必须基于实际文本，禁止虚构
3. **时间戳转换**：realTime 展示为绝对时间（如"13:45:02"），startTime 展示为录音内时间点（如"00:12:34"）
4. **不修改原有流程**：会后模式的 get-transcript.py 和所有 AI 分析能力保持原样

---

## 会议素材镜像器（meeting-id transcript only）

> 范围锁定：仅针对**已知 meetingChatId** 拉取并镜像文本素材，不做总结、问答、纪要增强。

### 推荐入口（AppKey 自动发现）

> 推荐优先使用自动发现入口：无需先手工准备 meetingChatId。

```bash
# 1) 先查看当前 appKey 可访问会议（最近 20 条）
# 默认排序：进行中优先，其次按更新时间倒序；末尾会给推荐候选和 --pick-index 示例
python3 scripts/huiji/list-my-meetings.py 0 20

# 2) 直接自动选择并拉取（默认优先进行中 state=0）
python3 scripts/huiji/pull-meeting.py --auto

# 可选：优先已完成会议（state=2）或按序号选择
python3 scripts/huiji/pull-meeting.py --auto --prefer-state 2
python3 scripts/huiji/pull-meeting.py --auto --pick-index 2
```

### 目标命令（最小可用）

- 支持两种入口：`meetingChatId` 与 `meetingNumber`（会议号会先解析为 meetingChatId）

```bash
# 兼容入口：调度驱动（默认 120s，可选 60/120/180）
python3 scripts/huiji/pull-meeting.py <meetingChatId> [--interval 120] [--timeout 3600]

# 短任务入口：单次增量拉取后退出（推荐给调度器）
python3 scripts/huiji/pull-once.py --meeting-chat-id <meetingChatId>

# 用户提前触发一次
python3 scripts/huiji/trigger-pull.py <meetingChatId>

# 查看本地状态（含锁/熔断/空跑计数）
python3 scripts/huiji/meeting-status.py <meetingChatId> --json
```

### 落盘结构（固定）

```text
cms-meeting-materials/{gateway}/{meetingChatId}/
├── manifest.json
├── checkpoint.json
├── fragments.ndjson
├── transcript.txt
├── pull.log
└── .stop（可选）
```

- 默认根目录：`~/.openclaw/cms-meeting-materials/{gateway}/`（多 agent 可共用）
- 可通过环境变量 `CMS_MEETING_MATERIALS_ROOT` 自定义基路径
- gateway 来源：`OPENCLAW_GATEWAY`（缺省为 `default`）

### 行为规则

1. 去重主键：`meetingChatId + segment_id + version`
2. 若 `manifest.is_fully_pulled=true` 且未传 `--force`，直接跳过
3. 已结束会议：一次全量拉取并收口，置 `status=completed` + `is_fully_pulled=true`
4. 进行中会议：基于 `checkpoint.last_start_time` 持续增量拉取，检测结束后自动收口
5. fail-soft：异常写入 `pull.log`，不破坏已有产物

### 状态查询与停止

- `meeting-status.py`：只读本地 cms-meeting-materials 状态，可用于离线检查
- `stop-pull.py`：写入 `.stop` 标记，请求 `pull-meeting.py` 在下一轮安全退出

### 调度驱动模式（120s）+ trigger（v1.10.6）

1. `pull-once.py` 是短任务入口：每次仅执行一轮增量拉取并退出，适配外部调度器。
2. `pull-meeting.py` 保留兼容：内部按 interval（默认 120s）循环调用短任务。
3. 护栏三件套：
   - **锁**：同会议 `{gateway}:{meetingChatId}` 互斥，锁占用时返回 `skipped_locked=true`
   - **停机**：`completed` / `连续3次无增量且非active` / `超过10小时TTL` 自动停止
   - **退避与熔断**：429/5xx/网络错误走指数退避（30→60→120→300 + 抖动），连续失败>=5 熔断 15 分钟
4. `trigger-pull.py` 支持用户提前触发一次；若已有任务在跑，返回 `running`（`running_skip`）。
5. 子代理模式可加 `--notify-file <path>`：
   - `pull-once.py --notify-file`：任务结束后向 JSONL 追加一条结构化事件（`meetingChatId/status/new_fragments/timestamp`）
   - `trigger-pull.py --notify-file`：同样在触发流程结束后追加一条事件，便于主 agent 异步感知子任务结果

## 约束

1. **鉴权**：所有接口只需 `appKey`（`XG_BIZ_API_KEY`），无需 access-token
2. **生产域名**：`sg-al-ai-voice-assistant.mediportal.com.cn/api`
3. **AI 分析基于原文**：所有分析由 AI 基于转写原文完成，不依赖平台预生成的报告或待办
4. **4.8 容错**：已结束会议必须 fallback 到 4.4，刚结束时 4.8 可能无内容
5. **统一入口**：获取会议原文时**必须使用 `get-transcript.py`**，禁止直接调用 4.4 / 4.10 / 4.8 脚本
5. **_id 后缀处理**：4.1 返回的 `_id` 可能有 `__数字` 后缀，用作 `meetingChatId` 时需截取或用 `originChatId`
6. **重试策略**：脚本内置最多重试 3 次，间隔 1 秒
7. **分页从 0 开始**：4.1 的 `pageNum` 从 0 开始
8. **依赖声明**：仅需环境变量 `XG_BIZ_API_KEY`，无需 `cms-auth-skills`
9. **增量优先**：有缓存时优先用 4.10 增量拉取，减少重复传输
10. **时间戳必须转换**：所有时间戳字段（createTime、startTime、realTime、meetingLength 等）向用户展示时必须转换为可读格式，禁止直接展示原始数字。详见上方「时间戳处理规范」
11. **防幻觉与术语准确性**：总结/待办/专题分析时，禁止虚构时间、人物、数据、决策；专业术语结合上下文智能纠错但不确定时保持原文；AI 归纳需诚实标注来源。详见上方「严格约束：防幻觉与术语准确性」
12. **路由严格遵守**：用户未提供会议号时必须走 4.1（归属维度），禁止从上下文记忆中自动取会议号跳过路由
13. **无结果引导**：4.1 查无结果时，必须主动提醒用户可提供会议号走 4.11 查询（因为 4.1 不含他人录制/发起的会议）
14. **API 校验错误不重试**：接口返回 `resultCode` 不为 `1` 的业务错误（如 `resultMsg: "meetingNumber不能为空"`）时，AI 必须**停止执行**，直接向用户展示错误原因。不得反复修改参数重试同一条接口。
15. **隐藏技术细节**：向用户输出时禁止展示内部技术过程，包括但不限于：
    - 原文获取策略的选择过程（如"先尝试 4.8"、"fallback 到 4.4"、"获取成功（有发言人区分）"等）
    - 接口调用细节（如"调了 4.1 接口"、"返回 resultCode: 1"等）
    - 脚本名称、缓存机制、增量拉取等实现细节
    - **所有 API 字段名**（如后端返回的任何 JSON key，无论中英文），必须全部翻译为人类语言后呈现
    - 原始 JSON 数据结构
    - **原则**：用户只需要看到结果（会议内容/总结/待办），不需要知道你怎么拿到的
16. **进行中会议的时间合理性过滤**：查询进行中会议时，API 可能返回历史异常数据（录音未正常结束导致状态卡在"进行中"）。AI 必须过滤掉创建时间超过 **2 天**的"进行中"记录，只保留今天和昨天的。向用户展示前静默过滤，无需解释

---

## 能力树

```
ai-huiji/
├── SKILL.md
├── .cache/
│   └── huiji/                              # 会议原文缓存（按 meetingChatId 存储）
│       └── shared/                         # 共享资料（按 meetingNumber/yyyyMMdd 存储）
├── openapi/
│   └── huiji/
│       ├── api-index.md                    # 接口索引
│       ├── chat-list-by-page.md            # 4.1 查询我的慧记列表
│       ├── list-by-meeting-number.md       # 4.11 按会议号查询慧记列表
│       ├── split-record-list.md            # 4.4 全量分片转写
│       ├── split-record-list-v2.md         # 4.10 增量分片转写
│       └── check-second-stt-v2.md          # 4.8 改写原文状态
├── examples/
│   └── huiji/
│       └── README.md                        # 面向外部部署者的 Quick Start 手册（触发示例 + 脚本用法）
└── scripts/
    └── huiji/
        ├── README.md                        # 脚本清单 + 使用示例
        ├── get-transcript.py                # 🌟 统一入口（自动处理全量/增量/改写/缓存）
        ├── list-my-meetings.py             # AppKey 可访问会议列表（meetingChatId 自动发现入口）
        ├── pull_core.py                    # 短任务共享核心（锁/停机/退避/熔断）
        ├── pull-once.py                    # 单次增量拉取并退出（调度器入口）
        ├── trigger-pull.py                 # 提前触发一次 pull-once
        ├── chat-list-by-page.py            # 4.1 分页查询
        ├── list-by-meeting-number.py       # 4.11 按会议号查询
        ├── split-record-list.py            # 4.4 全量分片转写（内部使用）
        ├── split-record-list-v2.py         # 4.10 增量分片转写（内部使用）
        ├── check-second-stt-v2.py          # 4.8 改写原文状态（内部使用）
        └── huiji-stream/                     # 会中实时模式（v1.10.1 新增）
            ├── stream-sync.py               # 核心：增量拉取 + checkpoint + 事件生成
            ├── event-processor.py           # 事件消费：APPEND/REPLACE/DELETE + 滚动摘要
            └── poll-scheduler.py           # 自适应轮询调度器
```
